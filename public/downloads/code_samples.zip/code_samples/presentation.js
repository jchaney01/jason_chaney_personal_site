//http://jsfiddle.net/SAWsA/11/


if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (searchElement /*, fromIndex */ ) {
        'use strict';
        if (this == null) {
            throw new TypeError();
        }
        var n, k, t = Object(this),
            len = t.length >>> 0;

        if (len === 0) {
            return -1;
        }
        n = 0;
        if (arguments.length > 1) {
            n = Number(arguments[1]);
            if (n != n) { // shortcut for verifying if it's NaN
                n = 0;
            } else if (n != 0 && n != Infinity && n != -Infinity) {
                n = (n > 0 || -1) * Math.floor(Math.abs(n));
            }
        }
        if (n >= len) {
            return -1;
        }
        for (k = n >= 0 ? n : Math.max(len - Math.abs(n), 0); k < len; k++) {
            if (k in t && t[k] === searchElement) {
                return k;
            }
        }
        return -1;
    };
}

_.mixin({crush: function(l, s, r) {return _.isObject(l)? (r = function(l) {return _.isObject(l)? _.flatten(_.map(l, s? _.identity:r)):l;})(l):[];}});

App.controller("presentationController", ['$scope','$log','$http','$filter','$timeout', function ($scope,$log,$http,$filter,$timeout) {
	$log.debug("Init presentation controller");

	$scope.products = []; //All items to choose form
	$scope.presentationProducts = []; //Items added to presentation
	$scope.sortingOrder = 'title'; //The product property to sort the filtered items by
	$scope.reverse = false; //If the sort order should be reversed
	$scope.filteredItems = []; //The ordered search result set
	$scope.itemsPerPage = 5; //Number to show per page
	$scope.pagedItems = []; //The pages of ordered search result set
	$scope.currentPage = 0; //The active page number
	$scope.query = ''; //This should be set on the input field

    $scope.presentationName = '';
	$scope.editing = false;
    $scope.addressedTo = '';
    $scope.addressedTo = '';
    $scope.clientName = '';
    $scope.templateId = 1;
    $scope.errors = null;



	$scope.getProducts = function(){
		$http({method: 'GET', url: '/product'}).
			success(function(data, status, headers, config) {
				$scope.products = data;
				$scope.search();
			}).
			error(function(data, status, headers, config) {
				$log.debug(data);
			});
	};

	//Helper to determine if a string exists in another string.
	var searchMatch = function (haystack, needle) {
		if (!needle) {
			return true;
		}
			return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;

	};

	//SETS FILTERED ITEMS - is called from view
	// init the filtered items
	$scope.search = function () {

		//SET FILTERED ITEMS TO THE SEARCH TERM
		//filteredItems becomes an array of items (objects) found in query (assigned as model on input filed) from all items array.
		$scope.filteredItems = $filter('filter')($scope.products, function (item) {
			//Laravel may return nested related data so we flatten it all out.
			var flat = _.crush(item);

			for (var i = 0; i < flat.length; i++) {
				if (flat[i]){
					if (searchMatch(flat[i], $scope.query)){
						return true;
					}
				}
			}
			return false;

		});
		//SORT FILTERED ITEMS
		// take care of the sorting order - pass in array of objects, what to sort by and if it should be reversed
		if ($scope.sortingOrder !== '') {
			$scope.filteredItems = $filter('orderBy')($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
		}
		$scope.currentPage = 0;

		// now group by pages

		$log.debug($scope.filteredItems);

		$scope.groupToPages();
	};

	//SET PAGED ITEMS
	//Sets pagedItems array to arrays of pages of items
	$scope.groupToPages = function () {
		$scope.pagedItems = [];

		for (var i = 0; i < $scope.filteredItems.length; i++) {
			if (i % $scope.itemsPerPage === 0) {
				$scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [ $scope.filteredItems[i] ];
			} else {
				$scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
			}
		}
	};

	//returns an array where each slot is a page number
	$scope.range = function (start, end) {
		var ret = [];
		if (!end) {
			end = start;
			start = 0;
		}
		for (var i = start; i < end; i++) {
			ret.push(i);
		}
		return ret;
	};

	$scope.prevPage = function () {
		if ($scope.currentPage > 0) {
			$scope.currentPage--;
		}
	};

	$scope.nextPage = function () {
		if ($scope.currentPage < $scope.pagedItems.length - 1) {
			$scope.currentPage++;
		}
	};

	$scope.setPage = function () {
		$scope.currentPage = this.n;
	};


	// change sorting order
	$scope.sort_by = function(newSortingOrder) {
		if ($scope.sortingOrder == newSortingOrder)
			$scope.reverse = !$scope.reverse;

		$scope.sortingOrder = newSortingOrder;

		// icon setup
		$('th i').each(function(){
			// icon reset
			$(this).removeClass().addClass('icon-sort');
		});
		if ($scope.reverse)
			$('th.'+new_sorting_order+' i').removeClass().addClass('icon-chevron-up');
		else
			$('th.'+new_sorting_order+' i').removeClass().addClass('icon-chevron-down');
	};

	//KICK THINGS OFF

    function init(){

        var $container = $('#packery');
        $container.packery({
            itemSelector: '.item',
            gutter: 10,
			columnWidth: 210,
			rowHeight: 250
        });
        $scope.pckry = $container.data('packery');
        $scope.getProducts();
        $container.packery('on','dragItemPositioned',$scope.updatePresentationProductOrder);
        $container.packery('on','layoutComplete',$scope.updatePresentationProductOrder);

        $timeout(function(){
            //Go get the presentation if in editing mode
            if($scope.editing != false){
                $log.debug("Editing mode detected in presentation controller");
                $http.get('/api/presentation/'+$scope.editing).then(function(res){
                    $log.debug(res.data);
                    $scope.presentationName=res.data.title;
                    $scope.clientName=res.data.clientName;
                    $scope.addressedTo=res.data.addressedTo;
                    $scope.templateId=res.data.templateId;
                    if(res.data.presentation_product.length){
                        _.each(res.data.presentation_product,function(element, index, list){

                            //JS PresentationProduct(s) are created from Product models.  However server-side presentationProduct models
                            //are more relational so we need to map Products to PresentationProducts.

                            var constructedProduct = {};

                            constructedProduct.active = element.product.active;
                            constructedProduct.created_at = element.product.created_at;
                            constructedProduct.description = element.product.description;
                            constructedProduct.description2 = element.product.description2;
                            constructedProduct.descriptionOverride = element.description;
                            constructedProduct.id = element.product.id;
                            constructedProduct.organization_id = element.product.organization_id;
                            constructedProduct.photo = element.product.photo;
                            constructedProduct.photo2 = element.product.photo2;
                            constructedProduct.photo2 = element.product.photo2;
                            constructedProduct.photo2_meta = element.product.photo2_meta;
                            constructedProduct.photo_meta = element.product.photo_meta;
                            constructedProduct.product_category = element.product.product_category;
                            constructedProduct.title = element.product.title;
                            constructedProduct.updated_at = element.product.updated_at;

                            $scope.presentationProducts.push(constructedProduct);
                        });
                        $timeout(function(){
                            $scope.pckry.reloadItems();
                            var itemElems = $scope.pckry.getItemElements();

                            for ( var i=0, len = itemElems.length; i < len; i++ ) {
                                var elem = itemElems[i];
                                var draggie = new Draggabilly( elem );
                                $scope.pckry.bindDraggabillyEvents( draggie );
                            }
                            $scope.pckry.layout();
                        });
                    }
                })
            }
        })
    }
    
    $scope.addProduct = function(item){
		item.descriptionOverride = '';
		//Check to see if it already exists
		if (_.findWhere($scope.presentationProducts,{id:item.id})==undefined){ //make sure it's not already added
			$scope.presentationProducts.push(item);
			$timeout(function(){
				$scope.pckry.reloadItems();
				var itemElems = $scope.pckry.getItemElements();
				if (itemElems.length != 0){ //If there are any presProducts at all
                    $log.debug("itemElems");
                    $log.debug(itemElems);
					var elem = _.last(itemElems); //Only grab the last one added as the others are draggable already
					var draggie = new Draggabilly( elem ,{
						handle: '.thumbArea'
					});
					$scope.pckry.bindDraggabillyEvents( draggie );
				}
				$scope.pckry.layout();
			});
		} else {
			alert(item.title+" is already added.");
		}
    };

    $scope.removeProduct = function(item){
		$log.debug('Requested to remove ID '+item.id);
        for (var i=0; i<$scope.presentationProducts.length; i++){
            if ($scope.presentationProducts[i].id == item.id){
                var targetIndex = i;
            }
        }

        //Pop it off the stack of presProducts
        $scope.presentationProducts.splice(targetIndex, 1);
		$timeout(function(){
			$scope.pckry.reloadItems();
			$scope.pckry.layout();
		})
    };

    $scope.updatePresentationProductOrder = function(){
        //http://codepen.io/desandro/pen/GcDbr
        var sortOrder = []; //index = position, value = record id
        var itemElems = $scope.pckry.getItemElements();
        sortOrder.length = 0; //purge the existing order
        for (var i=0; i< itemElems.length; i++) {
            sortOrder[i] = itemElems[i].getAttribute("tabindex");
        }
        //<-- sortOrder is now an array where each slot has the ID and the position is the order-->
        if ($scope.sortOrder !== JSON.stringify(sortOrder)){ //Packery fires the same event names for multiple events so we just verify it's new
            $scope.sortOrder = JSON.stringify(sortOrder);

            //Now we make a new array of real objects in the right order
            var newOrder = [];
            for (var i=0; i< sortOrder.length; i++) {
                newOrder.push(_.findWhere($scope.presentationProducts,{id:sortOrder[i]}));
            }
            //Now we have a fresh array of objects in the right order to send to the server
            $scope.presentationProducts = newOrder;
            $log.debug($scope.presentationProducts);

        }
    };

    $scope.submitForm = function(){



        $log.debug("Submit from called");

        var dataVO = {
            "presentation_products":$scope.presentationProducts,
            "presentation":{
                "title":$scope.presentationName,
                "addressedTo":$scope.addressedTo,
                "clientName":$scope.clientName,
                "templateId":$scope.templateId
            }
        };

        var url = '/presentation';
        if($scope.editing){
            dataVO.presentation.id = $scope.editing;
            url = '/api/presentation/'+$scope.editing;
        }


        $http({
            method: 'POST',
            url: url,
            data:dataVO
        }).
            success(function(data, status, headers, config) {
				$log.debug(data);
				if (data.status == 0){
					$scope.errors = data.message;
				} else {
					window.location = "/presentation"
				}
            }).
            error(function(data, status, headers, config) {
                $log.debug(data);
            });
    };

    init();
}]);