<?php

class LoginController extends BaseController {

    public function index()
    {

        $data=array("title"=>"Login");
        return View::make('login',$data);
    }

    public function dashboardIndex($dashboardId)
    {

        $dashboard = Dashboard::with("client")->find($dashboardId);
        if(is_null($dashboard)){
            App::abort(404);
        }
        $data=array("title"=>"$dashboard->title Login",'dashboard'=>$dashboard);
        return View::make('login_dashboard',$data);
    }


    public function store()
    {

        $creds = array(
            "email"=>Input::get('email'),
            "password"=>Input::get('password')
        );

        $v = Validator::make($creds,array(
            'email'=>"required|email",
            'password'=>"required",
        ));


        if($v->fails()){
            return Redirect::route('login')->withErrors($v)->withInput();
        };



        if (Auth::attempt($creds))
        {

            Session::flash('msg', "Welcome ".Auth::user()->name.".");
            Session::put('isAdmin',Auth::user()->id);
            return Redirect::route('user.index');

        } else {
            Session::flash('msg', "No user found with that info.");
            return Redirect::route('login')->withErrors($v)->withInput();
        }
    }
    public function dashboardStore($dashboardId)
    {
        $dashboard = Dashboard::find($dashboardId);

        if(is_null($dashboard)){
            Session::flash('msg', "That client page was not found.");
            return Redirect::route('login_dashboard',array($dashboardId))->withInput();
        }

        $creds = array(
            "password"=>Input::get('password')
        );

        $v = Validator::make($creds,array(
            'password'=>"required"
        ));

        if($v->fails()){
            return Redirect::route('login_dashboard',array($dashboardId))->withErrors($v)->withInput();
        };



        if ($creds['password'] == $dashboard->password)
        {

            Session::put('dashboardId',$dashboard->id);
            return Redirect::route('show_dashboard',array($dashboard->url));

        } else {
            Session::flash('msg', "Incorrect password.");
            return Redirect::route('login_dashboard',array($dashboardId))->withErrors($v)->withInput();
        }
    }



    public function logout(){
        Auth::logout();
        Session::flush();
        Session::flash('msg', "You have been logged out. Come again soon.");
        return Redirect::route('login');
    }

}